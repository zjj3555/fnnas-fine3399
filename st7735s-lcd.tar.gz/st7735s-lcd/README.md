# ST7735S LCD 驱动安装包

适用于 **Fine3399 (RK3399)** 开发板 + **0.96寸 160x80 TFT LCD (ST7735S)**

## 📋 系统要求

- **设备**: Fine3399 (RK3399) 开发板
- **LCD**: 0.96寸 ST7735S TFT LCD (160x80)
- **内核**: Linux 6.18.18-trim (需要与编译环境一致)
- **系统**: Debian 12 (bookworm) 或兼容系统
- **Python**: 3.x + Pillow

## 📦 文件说明

```
st7735s-lcd/
├── fb_st7735s.ko          # 内核模块 (已编译)
├── fb_st7735s.c           # 内核模块源码
├── Makefile               # 编译文件
├── lcd_display.py         # LCD 显示脚本
├── lcd-display.service    # systemd 服务文件
├── install.sh             # 安装脚本
├── uninstall.sh           # 卸载脚本
└── README.md              # 本说明文件
```

## 🚀 快速安装

### 1. 上传文件到目标机器

```bash
# 方法1: 使用 scp
scp -r st7735s-lcd/ user@目标机器IP:/tmp/

# 方法2: 使用 rsync
rsync -avz st7735s-lcd/ user@目标机器IP:/tmp/st7735s-lcd/
```

### 2. 登录目标机器并安装

```bash
# SSH 登录目标机器
ssh user@目标机器IP

# 进入安装目录
cd /tmp/st7735s-lcd

# 执行安装脚本
sudo bash install.sh
```

### 3. 验证安装

```bash
# 检查服务状态
sudo systemctl status lcd-display.service

# 检查 LCD 是否显示
# 应该看到系统信息（CPU、内存、IP 等）
```

## 🔧 手动安装

如果自动安装脚本不工作，可以手动安装：

### 1. 安装依赖

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-pip sysstat lm-sensors
pip3 install Pillow
```

### 2. 安装内核模块

```bash
# 复制模块
sudo cp fb_st7735s.ko /lib/modules/$(uname -r)/extra/

# 更新依赖
sudo depmod -a

# 加载模块
sudo insmod fb_st7735s.ko
```

### 3. 测试 LCD

```bash
# 运行显示脚本
sudo python3 lcd_display.py
```

### 4. 设置开机启动

```bash
# 复制服务文件
sudo cp lcd-display.service /etc/systemd/system/

# 重载 systemd
sudo systemctl daemon-reload

# 启用服务
sudo systemctl enable lcd-display.service

# 启动服务
sudo systemctl start lcd-display.service
```

## 📝 服务管理

```bash
# 查看状态
sudo systemctl status lcd-display.service

# 停止服务
sudo systemctl stop lcd-display.service

# 启动服务
sudo systemctl start lcd-display.service

# 重启服务
sudo systemctl restart lcd-display.service

# 查看日志
sudo journalctl -u lcd-display.service -f

# 禁用开机启动
sudo systemctl disable lcd-display.service
```

## ⚠️ 注意事项

1. **内核版本必须匹配**: 预编译的 `.ko` 文件只适用于编译时的内核版本
   - 当前版本: `6.18.18-trim`
   - 如果内核不同，需要重新编译模块

2. **重新编译模块** (如果内核不同):
   ```bash
   # 需要安装内核头文件
   sudo apt-get install -y linux-headers-$(uname -r)
   
   # 编译模块
   make clean
   make
   
   # 安装
   sudo bash install.sh
   ```

3. **设备树配置**: 确保设备树中已正确配置 SPI LCD 节点

4. **硬件连接**: 确保 LCD 正确连接到 SPI2 接口

## 🐛 故障排除

### LCD 不显示

```bash
# 检查模块是否加载
lsmod | grep st7735

# 检查 framebuffer
ls /dev/fb*

# 检查 GPIO 状态
sudo cat /sys/kernel/debug/gpio | grep -E "reset|dc|led"

# 检查 SPI 统计
cat /sys/bus/spi/devices/spi2.0/statistics/transfers
```

### 服务启动失败

```bash
# 查看详细日志
sudo journalctl -xeu lcd-display.service

# 手动测试
sudo insmod fb_st7735s.ko
sudo python3 lcd_display.py
```

### 花屏问题

检查 MADCTL 值是否正确。编辑 `fb_st7735s.c`，修改 MADCTL 值：

- `0x00`: 无旋转，RGB
- `0x08`: 无旋转，BGR
- `0x60`: 90° 旋转
- `0x68`: 90° 旋转 + BGR
- `0xA0`: 270° 旋转
- `0xA8`: 270° 旋转 + BGR

## 📄 许可证

GPL v2

## 👥 贡献

基于教程: https://github.com/zjj3555/AutoBuildImmortalWrt
