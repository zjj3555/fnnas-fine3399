#!/bin/bash
#
# ST7735S LCD 驱动卸载脚本
#
# 用法: sudo bash uninstall.sh
#

set -e

SERVICE_FILE="lcd-display.service"
KERNEL_VER=$(uname -r)
MODULE_INSTALL_DIR="/lib/modules/$KERNEL_VER/extra"

echo "========================================="
echo "  ST7735S LCD 驱动卸载脚本"
echo "========================================="
echo ""

# 检查 root 权限
if [ "$EUID" -ne 0 ]; then
    echo "❌ 需要 root 权限！请使用: sudo bash $0"
    exit 1
fi

echo "🛑 停止服务..."
systemctl stop $SERVICE_FILE 2>/dev/null || true
systemctl disable $SERVICE_FILE 2>/dev/null || true

echo "🗑️  删除服务文件..."
rm -f /etc/systemd/system/$SERVICE_FILE
systemctl daemon-reload

echo "🗑️  删除内核模块..."
rmmod fb_st7735s 2>/dev/null || true
rm -f "$MODULE_INSTALL_DIR/fb_st7735s.ko"
depmod -a

echo ""
echo "========================================="
echo "  ✅ 卸载完成！"
echo "========================================="
