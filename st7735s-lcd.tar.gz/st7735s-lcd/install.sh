#!/bin/bash
#
# ST7735S LCD 驱动安装脚本
# 适用于 Fine3399 (RK3399) 开发板 + 0.96寸 160x80 TFT LCD
#
# 用法: sudo bash install.sh
#

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODULE_DIR="$SCRIPT_DIR"
SERVICE_FILE="lcd-display.service"

echo "========================================="
echo "  ST7735S LCD 驱动安装脚本"
echo "  0.96寸 160x80 TFT 显示屏"
echo "========================================="
echo ""

# 检查 root 权限
if [ "$EUID" -ne 0 ]; then
    echo "❌ 需要 root 权限！请使用: sudo bash $0"
    exit 1
fi

# 检查内核版本
KERNEL_VER=$(uname -r)
echo "📋 内核版本: $KERNEL_VER"

# 检查内核模块
if [ ! -f "$MODULE_DIR/fb_st7735s.ko" ]; then
    echo "❌ 未找到 fb_st7735s.ko"
    exit 1
fi

# 检查模块是否兼容当前内核
MODULE_VER=$(modinfo "$MODULE_DIR/fb_st7735s.ko" 2>/dev/null | grep "vermagic" | awk '{print $2}')
if [ "$MODULE_VER" != "$KERNEL_VER" ]; then
    echo "⚠️  警告: 模块版本 ($MODULE_VER) 与当前内核 ($KERNEL_VER) 不匹配"
    echo "   可能需要重新编译模块"
    echo ""
    read -p "是否继续安装？(y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "已取消安装"
        exit 1
    fi
fi

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 python3"
    exit 1
fi

# 检查 PIL
if ! python3 -c "from PIL import Image" 2>/dev/null; then
    echo "⚠️  未安装 Pillow，正在安装..."
    pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow
fi

# 检查依赖工具
echo "📋 检查依赖..."
for cmd in mpstat sensors; do
    if ! command -v $cmd &> /dev/null; then
        echo "⚠️  未找到 $cmd，正在安装..."
        if [ "$cmd" = "mpstat" ]; then
            apt-get install -y sysstat
        elif [ "$cmd" = "sensors" ]; then
            apt-get install -y lm-sensors
        fi
    fi
done

echo ""
echo "📦 安装内核模块..."

# 卸载旧模块（如果存在）
rmmod fb_st7735s 2>/dev/null || true

# 复制模块到系统目录
MODULE_INSTALL_DIR="/lib/modules/$KERNEL_VER/extra"
mkdir -p "$MODULE_INSTALL_DIR"
cp "$MODULE_DIR/fb_st7735s.ko" "$MODULE_INSTALL_DIR/"

# 更新模块依赖
depmod -a

echo "✅ 内核模块已安装到 $MODULE_INSTALL_DIR/"

echo ""
echo "📝 安装 systemd 服务..."

# 复制服务文件
cp "$MODULE_DIR/$SERVICE_FILE" /etc/systemd/system/

# 修改服务文件中的路径为安装路径
sed -i "s|$MODULE_DIR/fb_st7735s.ko|$MODULE_INSTALL_DIR/fb_st7735s.ko|g" /etc/systemd/system/$SERVICE_FILE

# 重载 systemd
systemctl daemon-reload

# 启用服务
systemctl enable $SERVICE_FILE

echo "✅ systemd 服务已安装并启用"

echo ""
echo "🚀 启动服务..."

# 启动服务
systemctl start $SERVICE_FILE
sleep 3

# 检查服务状态
if systemctl is-active --quiet $SERVICE_FILE; then
    echo "✅ 服务启动成功！"
else
    echo "❌ 服务启动失败，请检查日志:"
    echo "   journalctl -xeu $SERVICE_FILE"
    exit 1
fi

echo ""
echo "========================================="
echo "  ✅ 安装完成！"
echo "========================================="
echo ""
echo "📋 服务管理命令:"
echo "  查看状态: sudo systemctl status $SERVICE_FILE"
echo "  停止服务: sudo systemctl stop $SERVICE_FILE"
echo "  启动服务: sudo systemctl start $SERVICE_FILE"
echo "  重启服务: sudo systemctl restart $SERVICE_FILE"
echo "  查看日志: sudo journalctl -u $SERVICE_FILE -f"
echo ""
echo "📁 文件位置:"
echo "  内核模块: $MODULE_INSTALL_DIR/fb_st7735s.ko"
echo "  服务文件: /etc/systemd/system/$SERVICE_FILE"
echo ""
echo "🔄 重启后 LCD 显示服务将自动运行"
