#!/bin/bash
#
# ST7735S LCD 一键安装命令
# 适用于其他相同配置的 Fine3399 机器
#

echo "========================================="
echo "  ST7735S LCD 一键安装"
echo "  Fine3399 + 0.96寸 160x80 TFT LCD"
echo "========================================="
echo ""

# 检查是否为 root
if [ "$EUID" -ne 0 ]; then
    echo "请使用 sudo 运行此脚本"
    echo "用法: sudo bash quick-install.sh"
    exit 1
fi

# 检查压缩包是否存在
PACKAGE="st7735s-lcd.tar.gz"
if [ ! -f "$PACKAGE" ]; then
    echo "❌ 未找到 $PACKAGE"
    echo "请先将压缩包上传到当前目录"
    exit 1
fi

echo "📦 解压安装包..."
tar -xzf "$PACKAGE"

echo "🚀 开始安装..."
cd st7735s-lcd
bash install.sh

echo ""
echo "========================================="
echo "  安装完成！"
echo "========================================="
echo ""
echo "LCD 应该已经显示系统信息"
echo ""
echo "常用命令:"
echo "  查看状态: sudo systemctl status lcd-display.service"
echo "  重启服务: sudo systemctl restart lcd-display.service"
echo "  查看日志: sudo journalctl -u lcd-display.service -f"
