import os
import time
from PIL import Image, ImageDraw, ImageFont


def get_cpu_usage(lang):
    if lang == "en":
        cpu_percent = (
            os.popen("mpstat 1 1 | awk '/Average:/ {printf \"%.1f\", 100-$12}'")
            .read()
            .strip()
        )
    elif lang == "zh":
        cpu_percent = (
            os.popen("mpstat 1 1 | awk '/平均时间:/ {printf \"%.1f\", 100-$12}'")
            .read()
            .strip()
        )
    return f"{cpu_percent}%" if cpu_percent else "0.0%"


def get_system_temp():
    cpu_temp = (
        os.popen("sensors | grep 'temp1' | head -n 1 | awk '{print $2}'")
        .read()
        .strip()
        .replace("+", "")
    )
    return f"{cpu_temp}" if cpu_temp else "0.0°C"


def get_network_speed(interface="enp1s0"):
    try:
        with open(f"/sys/class/net/{interface}/statistics/rx_bytes", "r") as f:
            rx = int(f.read().strip())
        with open(f"/sys/class/net/{interface}/statistics/tx_bytes", "r") as f:
            tx = int(f.read().strip())
    except Exception:
        return "↑ 0B/s", "↓ 0B/s"
    
    time.sleep(1)
    
    try:
        with open(f"/sys/class/net/{interface}/statistics/rx_bytes", "r") as f:
            rx_new = int(f.read().strip())
        with open(f"/sys/class/net/{interface}/statistics/tx_bytes", "r") as f:
            tx_new = int(f.read().strip())
    except Exception:
        return "↓ 0B/s", "↑ 0B/s"
    
    rx_diff = rx_new - rx
    tx_diff = tx_new - tx
    
    def format_speed(diff):
        if diff < 1024:
            return f"{diff}B/s"
        elif diff < 1024 * 1024:
            return f"{diff/1024:.1f}KB/s"
        else:
            return f"{diff/(1024*1024):.1f}MB/s"
    
    return f"↓ {format_speed(rx_diff)}", f"↑ {format_speed(tx_diff)}"


def get_lan_ip(interface="enp1s0"):
    try:
        # 多重过滤确保只保留纯IP
        cmd = (
            f"ifconfig {interface} | grep 'inet' | "
            "awk '{gsub(/addr:/, \"\", $2); print $2}' | "  # 强制删除"addr:"
            "grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | "  # 只保留IP格式
            "head -n 1"
        )
        ip = os.popen(cmd).read().strip()
        
        # 若ifconfig失败，用ip命令兜底
        if not ip:
            cmd = (
                f"ip addr show {interface} | grep 'inet ' | "
                "awk '{print $2}' | cut -d'/' -f1 | "
                "grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'"
            )
            ip = os.popen(cmd).read().strip()
        
        return ip if ip else "--"  # 只返回IP或--，无任何前缀
    except Exception:
        return "--"


def get_memory_usage():
    try:
        with open("/proc/meminfo", "r") as f:
            mem_data = f.readlines()
        total_mem = int([line for line in mem_data if "MemTotal:" in line][0].split()[1])
        avail_mem = int([line for line in mem_data if "MemAvailable:" in line][0].split()[1])
        used_percent = int(100 - (avail_mem / total_mem) * 100)
        return f"RAM: {used_percent}%"
    except Exception:
        return "RAM: --%"


def get_current_time():
    return time.strftime("%H:%M:%S", time.localtime())


def draw_text(draw, text, position, font, fill):
    draw.text(position, text, font=font, fill=fill, anchor=None)


def update_image(image, font_path, font_size, lang):
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(font_path, font_size)

    cpu_usage = get_cpu_usage(lang)
    system_temp = get_system_temp()
    net_down, net_up = get_network_speed("eth0")
    mem_usage = get_memory_usage()
    current_time = get_current_time()
    lan_ip = get_lan_ip("eth0")  # 现在仅返回纯IP或--

    # 保持布局，IP行只显示纯IP
    draw_text(draw, f"CPU: {cpu_usage}", (2, 2), font, fill=(10, 10, 240))
    draw_text(draw, system_temp, (85, 2), font, fill=(255, 10, 10))
    draw_text(draw, mem_usage, (2, 22), font, fill=(10, 255, 10))
    draw_text(draw, current_time, (85, 22), font, fill=(245, 245, 245))
    draw_text(draw, net_up, (2, 42), font, fill=(255, 10, 10))
    draw_text(draw, net_down, (85, 42), font, fill=(10, 255, 10))
    draw_text(draw, lan_ip, (2, 62), font, fill=(0, 191, 255))  # 纯IP显示

    return image


def rgba_to_rgb565(rgba_data):
    rgb565_data = bytearray(len(rgba_data) // 2)
    for i in range(0, len(rgba_data), 4):
        r = rgba_data[i] & 0xF8
        g = rgba_data[i + 1] & 0xFC
        b = rgba_data[i + 2] & 0xF8
        rgb565_data[i // 2] = r | g >> 5
        rgb565_data[i // 2 + 1] = ((g & 0x1C) << 3) | b >> 3
    return rgb565_data


def main():
    width = 160
    height = 80
    bytes_per_pixel = 2
    font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"  # Debian 字体
    font_size = 14
    lang = "en"

    try:
        print("脚本已启动，实时显示系统信息（按Ctrl+C退出）")
        while True:
            image = Image.new("RGB", (width, height), color=(0, 0, 0))
            updated_image = update_image(image, font_path, font_size, lang)
            rgba_data = updated_image.convert("RGBA").tobytes()
            rgb565_data = rgba_to_rgb565(rgba_data)
            with open("/dev/fb1", "wb") as fb:
                fb.write(rgb565_data)

    except KeyboardInterrupt:
        print("\n脚本已手动中断")
        exit(0)
    except Exception as e:
        print(f"运行错误: {str(e)}")
        exit(1)


if __name__ == "__main__":
    main()
