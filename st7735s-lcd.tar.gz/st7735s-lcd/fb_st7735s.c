// SPDX-License-Identifier: GPL-2.0
/*
 * Framebuffer driver for ST7735S SPI LCD
 * 0.96" 160x80 TFT display (270° rotation)
 *
 * Based on fbtft framework and panel-mipi-dbi
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/spi/spi.h>
#include <linux/gpio/consumer.h>
#include <linux/fb.h>
#include <linux/workqueue.h>

#define DRIVER_NAME	"fb_st7735s"
#define WIDTH		160
#define HEIGHT		80

/* ST7735S RAM offset for 160x80 display */
#define X_OFFSET	0
#define Y_OFFSET	24
#define BPP		16		/* RGB565 */
#define PIX_SIZE	(WIDTH * HEIGHT * BPP / 8)
#define SPI_MAX_SPEED	32000000

/* MIPI DCS commands */
#define SWRESET		0x01
#define SLPOUT		0x11
#define NORON		0x13
#define INVOFF		0x20
#define ALLPOFF		0x22
#define DISPON		0x29
#define CASET		0x2A
#define RASET		0x2B
#define RAMWR		0x2C
#define MADCTL		0x36
#define COLMOD		0x3A
#define FRMCTR1		0xB1
#define FRMCTR2		0xB2
#define FRMCTR3		0xB3
#define INVCTR		0xB4
#define PWCTR1		0xC0
#define PWCTR2		0xC1
#define PWCTR3		0xC2
#define PWCTR4		0xC3
#define PWCTR5		0xC4
#define VCOMCTR1	0xC5

struct st7735s_par {
	struct spi_device *spi;
	struct fb_info *info;
	struct gpio_desc *dc;
	struct gpio_desc *reset;
	struct gpio_desc *led;
	struct delayed_work deferred_work;
};

static void st7735s_spi_write(struct st7735s_par *par, const void *buf, size_t len)
{
	struct spi_transfer t = {
		.tx_buf = buf,
		.len = len,
		.speed_hz = SPI_MAX_SPEED,
	};
	struct spi_message m;

	spi_message_init(&m);
	spi_message_add_tail(&t, &m);
	spi_sync(par->spi, &m);
}

static void st7735s_write_cmd(struct st7735s_par *par, u8 cmd)
{
	gpiod_set_value_cansleep(par->dc, 0);
	st7735s_spi_write(par, &cmd, 1);
}

static void st7735s_write_data(struct st7735s_par *par, const u8 *data, size_t len)
{
	gpiod_set_value_cansleep(par->dc, 1);
	st7735s_spi_write(par, data, len);
}

static void st7735s_write(struct st7735s_par *par, u8 cmd, const u8 *data, size_t len)
{
	st7735s_write_cmd(par, cmd);
	if (len)
		st7735s_write_data(par, data, len);
}

static void st7735s_set_addr_win(struct st7735s_par *par, u8 xs, u8 xe, u8 ys, u8 ye)
{
	u8 data[4];

	/* Add RAM offset */
	xs += X_OFFSET;
	xe += X_OFFSET;
	ys += Y_OFFSET;
	ye += Y_OFFSET;

	/* Column address */
	data[0] = 0;
	data[1] = xs;
	data[2] = 0;
	data[3] = xe;
	st7735s_write(par, CASET, data, 4);

	/* Page address */
	data[0] = 0;
	data[1] = ys;
	data[2] = 0;
	data[3] = ye;
	st7735s_write(par, RASET, data, 4);
}

/* Update the entire framebuffer to LCD */
static void st7735s_update_display(struct st7735s_par *par, u8 *fbmem)
{
	size_t len = PIX_SIZE;

	st7735s_set_addr_win(par, 0, WIDTH - 1, 0, HEIGHT - 1);
	st7735s_write_cmd(par, RAMWR);

	/* Send pixel data (DC high) */
	gpiod_set_value_cansleep(par->dc, 1);

	/* Send entire framebuffer directly (already in Big-Endian RGB565) */
	st7735s_spi_write(par, fbmem, len);
}

/* Deferred work handler - called when framebuffer is modified */
static void st7735s_deferred_io(struct work_struct *work)
{
	struct st7735s_par *par = container_of(work, struct st7735s_par, deferred_work.work);

	st7735s_update_display(par, par->info->screen_buffer);
}

static void st7735s_hw_reset(struct st7735s_par *par)
{
	/* ACTIVE LOW reset: value 1 = assert reset (LOW), value 0 = release (HIGH) */
	gpiod_set_value(par->reset, 1);  /* Assert reset: physical LOW */
	msleep(50);
	gpiod_set_value(par->reset, 0);  /* Release reset: physical HIGH */
	msleep(150);
}

/* Initialize ST7735S controller */
static int st7735s_init(struct st7735s_par *par)
{
	u8 data[16];

	st7735s_hw_reset(par);

	/* Software reset */
	st7735s_write_cmd(par, SWRESET);
	msleep(150);

	/* Sleep out */
	st7735s_write_cmd(par, SLPOUT);
	msleep(200);

	/* Frame Rate Control 1 (normal mode) */
	data[0] = 0x01;
	data[1] = 0x2C;
	data[2] = 0x2D;
	st7735s_write(par, FRMCTR1, data, 3);

	/* Frame Rate Control 2 (idle mode) */
	data[0] = 0x01;
	data[1] = 0x2C;
	data[2] = 0x2D;
	st7735s_write(par, FRMCTR2, data, 3);

	/* Frame Rate Control 3 (partial mode) */
	data[0] = 0x01;
	data[1] = 0x2C;
	data[2] = 0x2D;
	data[3] = 0x01;
	data[4] = 0x2C;
	data[5] = 0x2D;
	st7735s_write(par, FRMCTR3, data, 6);

	/* Display Inversion Control */
	data[0] = 0x07;
	st7735s_write(par, INVCTR, data, 1);

	/* Power Control 1 */
	data[0] = 0xA2;
	data[1] = 0x02;
	data[2] = 0x84;
	st7735s_write(par, PWCTR1, data, 3);

	/* Power Control 2 */
	data[0] = 0xC5;
	st7735s_write(par, PWCTR2, data, 1);

	/* Power Control 3 */
	data[0] = 0x0A;
	data[1] = 0x00;
	st7735s_write(par, PWCTR3, data, 2);

	/* Power Control 4 */
	data[0] = 0x8A;
	data[1] = 0x2A;
	st7735s_write(par, PWCTR4, data, 2);

	/* Power Control 5 */
	data[0] = 0x8A;
	data[1] = 0xEE;
	st7735s_write(par, PWCTR5, data, 2);

	/* VCOM Control 1 */
	data[0] = 0x0E;
	st7735s_write(par, VCOMCTR1, data, 1);

	/* Display Inversion Off */
	st7735s_write_cmd(par, INVOFF);

	/* Memory Access Control
	 * MADCTL: 0x68 = MX | MV | BGR (for landscape mode)
	 * This gives 160x80 display
	 */
	data[0] = 0x68;
	st7735s_write(par, MADCTL, data, 1);

	/* Pixel Format Set: RGB565 */
	data[0] = 0x05;
	st7735s_write(par, COLMOD, data, 1);
	msleep(10);

	/* Normal Display Mode On */
	st7735s_write_cmd(par, NORON);
	msleep(10);

	/* Display On */
	st7735s_write_cmd(par, DISPON);
	msleep(100);

	return 0;
}

/* Framebuffer operations */
static int st7735s_fb_check_var(struct fb_var_screeninfo *var, struct fb_info *info)
{
	if (var->xres != WIDTH || var->yres != HEIGHT ||
	    var->xres_virtual != WIDTH || var->yres_virtual != HEIGHT ||
	    var->bits_per_pixel != BPP) {
		var->xres = WIDTH;
		var->yres = HEIGHT;
		var->xres_virtual = WIDTH;
		var->yres_virtual = HEIGHT;
		var->bits_per_pixel = BPP;
		var->red.offset = 11;
		var->red.length = 5;
		var->green.offset = 5;
		var->green.length = 6;
		var->blue.offset = 0;
		var->blue.length = 5;
		var->transp.offset = 0;
		var->transp.length = 0;
	}
	return 0;
}

static int st7735s_fb_set_par(struct fb_info *info)
{
	return 0;
}

static int st7735s_fb_blank(int blank_mode, struct fb_info *info)
{
	return 0;
}

static void st7735s_fb_fillrect(struct fb_info *info, const struct fb_fillrect *rect)
{
	sys_fillrect(info, rect);
}

static void st7735s_fb_copyarea(struct fb_info *info, const struct fb_copyarea *area)
{
	sys_copyarea(info, area);
}

static void st7735s_fb_imageblit(struct fb_info *info, const struct fb_image *image)
{
	sys_imageblit(info, image);
}

/* Called when userspace writes to framebuffer */
static ssize_t st7735s_fb_write(struct fb_info *info, const char __user *buf,
				size_t count, loff_t *ppos)
{
	struct st7735s_par *par = info->par;
	ssize_t ret;

	ret = fb_sys_write(info, buf, count, ppos);

	/* Schedule deferred update to LCD */
	schedule_delayed_work(&par->deferred_work, msecs_to_jiffies(10));

	return ret;
}

static const struct fb_ops st7735s_fb_ops = {
	.owner		= THIS_MODULE,
	.fb_read	= fb_sys_read,
	.fb_write	= st7735s_fb_write,
	.fb_fillrect	= st7735s_fb_fillrect,
	.fb_copyarea	= st7735s_fb_copyarea,
	.fb_imageblit	= st7735s_fb_imageblit,
	.fb_check_var	= st7735s_fb_check_var,
	.fb_set_par	= st7735s_fb_set_par,
	.fb_blank	= st7735s_fb_blank,
};

/* SPI driver */
static int st7735s_probe(struct spi_device *spi)
{
	struct st7735s_par *par;
	struct fb_info *info;
	struct device *dev = &spi->dev;
	void *fbmem;
	int ret;

	dev_info(dev, "ST7735S LCD probe started\n");

	par = devm_kzalloc(dev, sizeof(*par), GFP_KERNEL);
	if (!par)
		return -ENOMEM;

	par->spi = spi;
	spi_set_drvdata(spi, par);

	/* Setup SPI */
	spi->bits_per_word = 8;
	spi->mode = SPI_MODE_0;
	spi->max_speed_hz = SPI_MAX_SPEED;
	ret = spi_setup(spi);
	if (ret) {
		dev_err(dev, "SPI setup failed: %d\n", ret);
		return ret;
	}

	/* Get GPIOs */
	par->dc = devm_gpiod_get(dev, "dc", GPIOD_OUT_LOW);
	if (IS_ERR(par->dc)) {
		dev_err(dev, "Failed to get dc-gpios\n");
		return PTR_ERR(par->dc);
	}

	par->reset = devm_gpiod_get_optional(dev, "reset", GPIOD_OUT_LOW);
	if (IS_ERR(par->reset))
		return PTR_ERR(par->reset);
	gpiod_set_value(par->reset, 0);  /* Release reset (HIGH for ACTIVE LOW) */

	par->led = devm_gpiod_get_optional(dev, "led", GPIOD_OUT_LOW);
	if (IS_ERR(par->led))
		return PTR_ERR(par->led);

	/* Initialize LCD */
	ret = st7735s_init(par);
	if (ret) {
		dev_err(dev, "LCD init failed\n");
		return ret;
	}

	/* Allocate framebuffer */
	fbmem = devm_kzalloc(dev, PIX_SIZE, GFP_KERNEL);
	if (!fbmem)
		return -ENOMEM;

	/* Allocate fb_info */
	info = framebuffer_alloc(0, dev);
	if (!info) {
		dev_err(dev, "Failed to allocate framebuffer\n");
		return -ENOMEM;
	}

	par->info = info;
	info->par = par;
	info->screen_buffer = fbmem;
	info->screen_size = PIX_SIZE;

	strscpy(info->fix.id, DRIVER_NAME, sizeof(info->fix.id));
	info->fix.smem_start = 0;
	info->fix.smem_len = PIX_SIZE;
	info->fix.type = FB_TYPE_PACKED_PIXELS;
	info->fix.visual = FB_VISUAL_TRUECOLOR;
	info->fix.line_length = WIDTH * BPP / 8;
	info->fix.accel = FB_ACCEL_NONE;

	info->var.xres = WIDTH;
	info->var.yres = HEIGHT;
	info->var.xres_virtual = WIDTH;
	info->var.yres_virtual = HEIGHT;
	info->var.bits_per_pixel = BPP;
	info->var.red.offset = 11;
	info->var.red.length = 5;
	info->var.green.offset = 5;
	info->var.green.length = 6;
	info->var.blue.offset = 0;
	info->var.blue.length = 5;
	info->var.transp.offset = 0;
	info->var.transp.length = 0;
	info->var.activate = FB_ACTIVATE_NOW;

	info->fbops = &st7735s_fb_ops;
	info->flags = FBINFO_HWACCEL_NONE;

	/* Initialize deferred work */
	INIT_DELAYED_WORK(&par->deferred_work, st7735s_deferred_io);

	ret = register_framebuffer(info);
	if (ret < 0) {
		dev_err(dev, "Framebuffer registration failed: %d\n", ret);
		framebuffer_release(info);
		return ret;
	}

	/* Test: write red color to LCD */
	memset(fbmem, 0xF8, PIX_SIZE);  // Red color 
	st7735s_update_display(par, fbmem);
	dev_info(dev, "ST7735S LCD test write done\n");

	dev_info(dev, "ST7735S LCD %dx%d framebuffer registered as %s\n",
		 WIDTH, HEIGHT, info->fix.id);

	return 0;
}

static void st7735s_remove(struct spi_device *spi)
{
	struct st7735s_par *par = spi_get_drvdata(spi);

	if (par && par->info) {
		cancel_delayed_work_sync(&par->deferred_work);
		unregister_framebuffer(par->info);
		framebuffer_release(par->info);
	}
	dev_info(&spi->dev, "ST7735S LCD removed\n");
}

static const struct spi_device_id st7735s_spi_ids[] = {
	{ "st7735s", 0 },
	{ }
};
MODULE_DEVICE_TABLE(spi, st7735s_spi_ids);

static const struct of_device_id st7735s_of_ids[] = {
	{ .compatible = "sitronix,st7735s" },
	{ .compatible = "sitronix,st7735r" },
	{ .compatible = "sitronix,st7789v" },
	{ }
};
MODULE_DEVICE_TABLE(of, st7735s_of_ids);

static struct spi_driver st7735s_driver = {
	.driver = {
		.name = DRIVER_NAME,
		.of_match_table = st7735s_of_ids,
	},
	.id_table = st7735s_spi_ids,
	.probe = st7735s_probe,
	.remove = st7735s_remove,
};

module_spi_driver(st7735s_driver);

MODULE_DESCRIPTION("Framebuffer driver for ST7735S SPI LCD (160x80)");
MODULE_AUTHOR("Fine3399 User");
MODULE_LICENSE("GPL");
MODULE_ALIAS("spi:st7735s");
